package Screens;

import javax.swing.*;
import java.awt.*;
import java.util.LinkedList;

public class GameScreen extends JPanel {
    private Snake snake; // Reference to the snake object

    public GameScreen(JFrame window) {
        this.setBounds(0, 0, window.getWidth(), window.getHeight());
        // Initialize Snake (starting position can be adjusted)
        snake = new Snake(10, 10); // Starting at (10, 10)
        snake.addHead(11, 10); // Adding a second segment for better visualization
    }// end of GameScreen method

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Set background color for better visibility
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, getWidth(), getHeight());
        // Draw the snake
        g.setColor(Color.GREEN);
    }

    public void addSnakeSegment(int x, int y) {
        snake.addHead(x, y);
        snake.removeTail();
        repaint();
    }// end of addSnakeSegment method

}
