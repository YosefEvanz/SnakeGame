// Name: 
// Class: CS 240
// Assignment: 
// File: SnakeGame.java

import javax.swing.*;
import Screens.GameScreen; // Import GameScreen from Screens package
import Screens.TitleScreen; // Import TitleScreen from Screens package

public class SnakeGame {
    public static final int WINDOW_WIDTH = 800;
    public static final int WINDOW_HEIGHT = 800;

    public static TitleScreen titleScreen;
    public static GameScreen gameScreen;

    public static void main(String[] args) {
        JFrame window = new JFrame("Snake Game");
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        window.setLayout(null);
    
        // Initialize titleScreen and gameScreen
        titleScreen = new TitleScreen(window, event -> {
            startButtonClicked(window);
        });
        gameScreen = new GameScreen(window);
    
        // Set bounds for titleScreen and gameScreen
        titleScreen.setBounds(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
        gameScreen.setBounds(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
    
        // Add title screen first
        window.add(titleScreen);
        window.add(gameScreen);
        gameScreen.setVisible(false); // Hide game screen initially
    
        window.setVisible(true); // Show the window after components are added
    
        System.out.println("end");
    }// end of main method
    

    private static void startButtonClicked(JFrame parent) {
        titleScreen.setVisible(false);
        gameScreen.setVisible(true);
        gameScreen.addSnakeSegment(12, 10);
        gameScreen.addSnakeSegment(13, 10);
    }// end of startButtonClicked method
}// end of SnakeGame class